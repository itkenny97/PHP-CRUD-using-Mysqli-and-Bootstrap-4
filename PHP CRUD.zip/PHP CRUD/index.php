<?php
require_once("php/config.php");
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
	<title>PHP CRUD</title>
</head>
<body>
<div class="container">
	<div class="card mt-5">
	  <h1 class="card-header display-4">PHP CRUD<span class="float-right"><button class="btn btn-primary" data-toggle="modal" data-target="#add">Add New User</button></span></h1>
	  
		<?php
		if (isset($_SESSION['message'])) {
			echo "<div class='alert alert-primary text-center'>".$_SESSION['message']."</div>";
				session_destroy();
		}
				
		?>
	  <div class="card-body">
			<table class="table table-striped">
				<thead class="thead-dark">
					<tr>
						<th>ID</th>
						<th>Lastname</th>
						<th>Firstname</th>
						<th>Middlename</th>
						<th>Gender</th>
            <th>Username</th>
            <th>Password</th>
						<th>Action</th>

					</tr>
				</thead>
				<tbody>
					<?php
						$sql = "SELECT * FROM tbl_users";
						$result = $connection->query($sql);
						if ($result->num_rows>0) {
							while ($row = $result->fetch_assoc()) {
								
						?>
					<tr>
						<td><?=$row['id'];?></td>
						<td><?=$row['lastname'];?></td>
						<td><?=$row['firstname'];?></td>
						<td><?=$row['middlename'];?></td>
						<td><?=$row['gender'];?></td>
            <td><?=$row['username'];?></td>
            <td><?=$row['password'];?></td>
						<input type="hidden" name="id" value="<?=$row['id'];?>">
						<td><a data-toggle="modal" data-target="#update<?=$row['id'];?>" href="index.php?id=<?=$row['id'];?>" class="btn btn-success">Edit</a> 

							<a href="php/delete.php?id=<?=$row['id'];?>" onclick="return confirm('Are you sure?');" class="btn btn-danger">Delete</a></td>
					</tr>
<!-- Modal -->
<div class="modal fade" id="update<?=$row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h5 class="modal-title text-white" id="exampleModalLabel">Update</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="php/function.php?id=<?=$row['id'];?>" method="POST">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            <label>Lastname</label>
            <input type="text" class="form-control" name="lastname" placeholder="Lastname" value="<?=$row['lastname'];?>" required>
            <label>Firstname</label>
            <input type="text" class="form-control" name="firstname" placeholder="Firstname" value="<?=$row['firstname'];?>" required>
            <label>MiddleName</label>
            <input type="text" class="form-control" name="middlename" placeholder="Middlename" value="<?=$row['middlename'];?>" required>
            <label>Gender</label>
            <input type="text" disabled class="form-control" name="gender" placeholder="Gender" value="<?=$row['gender'];?>" required>
          </div>
          <div class="col-md-6">
            <label>Username</label>
            <input type="text" class="form-control" name="username" placeholder="Username" value="<?=$row['username'];?>" required>
            <label>Password</label>
            <input type="password" class="form-control" name="password" placeholder="Password" value="<?=$row['password'];?>" required>
        </div>
      	</div>
  		</div>
      <div class="modal-footer">
        <button name="update" class="btn btn-success">Submit</button>
        <!-- <a class="btn btn-success" href="php/update.php?id=<?=$row['id'];?>">Submit</a> -->
      </div>
      </form>
      

    </div>
  </div>
</div>
					<?php

							}
						}
						?>
				</tbody>
			</table>
		</div>
	  </div>
	</div>
    
<!-- Modal -->
<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h5 class="modal-title text-white" id="exampleModalLabel">Add New User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="php/function.php" method="POST">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            <label>Lastname</label>
            <input type="text" class="form-control" name="lastname" placeholder="Lastname" required>
            <label>Firstname</label>
            <input type="text" class="form-control" name="firstname" placeholder="Firstname" required>
            <label>MiddleName</label>
            <input type="text" class="form-control" name="middlename" placeholder="Middlename" required>
            <label>Gender</label>
            <select class="form-control" name="gender">
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div class="col-md-6">
            <label>Username</label>
            <input type="text" class="form-control" name="username" placeholder="Username" required>
            <label>Password</label>
            <input type="password" class="form-control" name="password" placeholder="Password" required>
        </div>
      	</div>
  		</div>
      <div class="modal-footer">
        <button name="add" class="btn btn-primary">Submit</button>
      </div>
      </form>
      

    </div>
  </div>
</div>

<script type="text/javascript" src="js/jquery/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="bootstrap4/js/bootstrap.min.js"></script>
</body>
</html>