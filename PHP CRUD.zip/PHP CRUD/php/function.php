<?php
require_once("config.php");
session_start();

if(isset($_POST['add'])){
	$lastname = $_POST['lastname'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$gender = $_POST['gender'];

	$encryptedpass = md5($password);
	$sql = "SELECT * FROM tbl_users WHERE username='$username' or lastname='$lastname' AND firstname='$firstname'";
	$result = $connection->query($sql);
	if ($result->num_rows>=1) {
		$_SESSION['message'] = "User Already Exist";
		header("Location:../index.php");
	}
	
	else{
		$sql = "INSERT INTO tbl_users (lastname,firstname,middlename,gender,username,password)VALUES('$lastname','$firstname','$middlename','$gender','$username','$encryptedpass')";
		$result = $connection->query($sql);
		$_SESSION['message'] = "User Added Successfully";
		header("Location:../index.php");
	}
}

if (isset($_POST['update'])) {
	$id = $_GET['id'];
	$lastname = $_POST['lastname'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	$encryptedpass = md5($password);

		$sql = "UPDATE `tbl_users` SET lastname='$lastname', firstname='$firstname', middlename='$middlename', username='$username', password='$encryptedpass' WHERE id = $id";
		$result = $connection->query($sql);
		$_SESSION['message'] = "Updated Successfully";
		header("Location:../index.php");
	
	
}

?>