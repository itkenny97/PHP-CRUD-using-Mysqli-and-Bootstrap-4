<?php
require_once("config.php");
session_start();

$id = $_GET['id'];
$sql = "DELETE FROM tbl_users WHERE id = $id";
$result = $connection->query($sql);
$_SESSION['message'] = "Deleted Successfully";
header("Location:../index.php");

?>